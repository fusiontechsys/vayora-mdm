# Vayora MDM Agent (Android)
Kotlin Android Enterprise agent (device owner + work profile). Package `com.vayora.mdm.agent`, minSdk 26.
Features: QR/work-profile enrollment, policy enforcement (password, camera, USB, VPN, Wi-Fi, kiosk, blocked apps), compliance
reporting, lock / lost mode / restart / wipe / remove work profile, private-APK install, Firebase push wake-ups (options come from the server).
Phone-only build: push this folder to a GitHub repo, run **Actions > Generate release keystore** once, add the 4 secrets,
then **Actions > Build Vayora MDM Agent APK** and download the artifact. Upload the APK to the server at
`backend/instance/agent/vayora-mdm-agent.apk`.
The new push/Wi-Fi/VPN/kiosk/lost-mode code has not been compiled yet: if the build fails, send the first `e:` line.

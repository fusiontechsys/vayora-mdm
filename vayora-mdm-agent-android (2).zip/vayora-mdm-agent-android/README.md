# Vayora MDM Agent (Android)
Kotlin Android Enterprise agent (device owner + work profile), package `com.vayora.mdm.agent`, minSdk 26.
Used by the "Vayora Agent" management engine (devices enrolled with the Google engine use Google's Android Device Policy instead).
Phone-only build: push this folder to a GitHub repo, run **Actions > Generate release keystore** once, add the 4 secrets,
then **Actions > Build Vayora MDM Agent APK** and download the artifact. Upload the APK to the server at
`backend/instance/agent/vayora-mdm-agent.apk`.
The push / Wi-Fi / VPN / kiosk / lost-mode code has not been compiled yet: if the build fails, send the first `e:` line.

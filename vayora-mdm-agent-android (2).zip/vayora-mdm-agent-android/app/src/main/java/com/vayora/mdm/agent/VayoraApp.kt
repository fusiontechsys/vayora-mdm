package com.vayora.mdm.agent

import android.app.Application
import com.vayora.mdm.agent.push.PushManager

class VayoraApp : Application() {
    override fun onCreate() {
        super.onCreate()
        PushManager.init(this)          // no-op until the server has supplied push options
    }
}

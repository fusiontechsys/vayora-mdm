package com.vayora.mdm.agent.work

import android.content.Context
import androidx.work.*
import com.vayora.mdm.agent.core.SyncEngine
import java.util.concurrent.TimeUnit

class EnrollWorker(ctx: Context, p: WorkerParameters) : Worker(ctx, p) {
    override fun doWork(): Result = when (SyncEngine.enroll(applicationContext)) {
        is SyncEngine.Outcome.Ok -> { Scheduler.schedulePeriodic(applicationContext); Scheduler.syncNow(applicationContext); Result.success() }
        is SyncEngine.Outcome.Retry -> Result.retry()
        else -> Result.failure()
    }
}

class SyncWorker(ctx: Context, p: WorkerParameters) : Worker(ctx, p) {
    override fun doWork(): Result = when (SyncEngine.sync(applicationContext)) {
        is SyncEngine.Outcome.Retry -> Result.retry()
        else -> Result.success()
    }
}

class PushRegisterWorker(ctx: Context, p: WorkerParameters) : Worker(ctx, p) {
    override fun doWork(): Result {
        val store = com.vayora.mdm.agent.data.Store(applicationContext)
        if (store.pushConfig == null) return Result.success()
        if (!store.enrolled || !com.vayora.mdm.agent.push.PushManager.init(applicationContext)) return Result.retry()
        return try {
            val token = com.google.android.gms.tasks.Tasks.await(
                com.google.firebase.messaging.FirebaseMessaging.getInstance().token, 20, TimeUnit.SECONDS)
            com.vayora.mdm.agent.net.ApiClient.post(store.serverUrl!!, "/api/v1/device/push-token", store.deviceToken,
                org.json.JSONObject().put("token", token))
            store.pushRegistered = true
            Result.success()
        } catch (e: Exception) { Result.retry() }
    }
}

object Scheduler {
    private val net = Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build()

    fun enqueueEnroll(ctx: Context) {
        WorkManager.getInstance(ctx).enqueueUniqueWork("enroll", ExistingWorkPolicy.REPLACE,
            OneTimeWorkRequest.Builder(EnrollWorker::class.java).setConstraints(net)
                .setBackoffCriteria(BackoffPolicy.EXPONENTIAL, 30, TimeUnit.SECONDS).build())
    }

    /** Android's minimum periodic interval is 15 minutes; commands are delivered at the next check-in. */
    fun schedulePeriodic(ctx: Context) {
        WorkManager.getInstance(ctx).enqueueUniquePeriodicWork("sync", ExistingPeriodicWorkPolicy.UPDATE,
            PeriodicWorkRequest.Builder(SyncWorker::class.java, 15, TimeUnit.MINUTES).setConstraints(net).build())
    }

    fun syncNow(ctx: Context) {
        WorkManager.getInstance(ctx).enqueueUniqueWork("sync-now", ExistingWorkPolicy.REPLACE,
            OneTimeWorkRequest.Builder(SyncWorker::class.java).setConstraints(net).build())
    }

    fun enqueuePushRegister(ctx: Context) {
        WorkManager.getInstance(ctx).enqueueUniqueWork("push-register", ExistingWorkPolicy.REPLACE,
            OneTimeWorkRequestBuilder<PushRegisterWorker>().setConstraints(net)
                .setBackoffCriteria(BackoffPolicy.EXPONENTIAL, 1, TimeUnit.MINUTES).build())
    }

    fun cancelAll(ctx: Context) = WorkManager.getInstance(ctx).cancelAllWork()
}

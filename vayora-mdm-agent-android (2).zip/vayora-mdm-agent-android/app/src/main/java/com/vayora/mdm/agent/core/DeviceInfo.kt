package com.vayora.mdm.agent.core

import android.app.KeyguardManager
import android.app.admin.DevicePolicyManager
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.BatteryManager
import android.os.Build
import android.os.Environment
import android.os.StatFs
import com.vayora.mdm.agent.BuildConfig
import org.json.JSONObject

object DeviceInfo {
    fun managementMode(ctx: Context): String {
        val dpm = ctx.getSystemService(Context.DEVICE_POLICY_SERVICE) as DevicePolicyManager
        return when {
            dpm.isDeviceOwnerApp(ctx.packageName) -> "device_owner"
            dpm.isProfileOwnerApp(ctx.packageName) -> "profile_owner"
            else -> "none"
        }
    }

    /**
     * Only technical device facts. No contacts, messages, location, browsing, personal apps or IMEI.
     * On BYOD this runs inside the work profile, so battery/storage are the only device-wide values.
     */
    fun collect(ctx: Context): JSONObject {
        val dpm = ctx.getSystemService(Context.DEVICE_POLICY_SERVICE) as DevicePolicyManager
        val mode = managementMode(ctx)
        val o = JSONObject()
        o.put("management_mode", mode)
        o.put("manufacturer", Build.MANUFACTURER)
        o.put("model", Build.MODEL)
        o.put("android_version", Build.VERSION.RELEASE)
        o.put("sdk_int", Build.VERSION.SDK_INT)
        o.put("security_patch", Build.VERSION.SECURITY_PATCH)
        o.put("agent_version", BuildConfig.VERSION_NAME)

        val bat = ctx.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        if (bat != null) {
            val level = bat.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)
            val scale = bat.getIntExtra(BatteryManager.EXTRA_SCALE, -1)
            if (level >= 0 && scale > 0) o.put("battery_pct", level * 100 / scale)
            val st = bat.getIntExtra(BatteryManager.EXTRA_STATUS, -1)
            o.put("battery_charging", st == BatteryManager.BATTERY_STATUS_CHARGING || st == BatteryManager.BATTERY_STATUS_FULL)
        }
        try {
            val fs = StatFs(Environment.getDataDirectory().path)
            o.put("storage_total_mb", fs.totalBytes / (1024 * 1024))
            o.put("storage_free_mb", fs.availableBytes / (1024 * 1024))
        } catch (e: Exception) { /* leave out */ }

        o.put("encryption_status", when (dpm.storageEncryptionStatus) {
            DevicePolicyManager.ENCRYPTION_STATUS_ACTIVE, DevicePolicyManager.ENCRYPTION_STATUS_ACTIVE_DEFAULT_KEY -> "active"
            DevicePolicyManager.ENCRYPTION_STATUS_ACTIVE_PER_USER -> "active_per_user"
            DevicePolicyManager.ENCRYPTION_STATUS_INACTIVE -> "inactive"
            DevicePolicyManager.ENCRYPTION_STATUS_UNSUPPORTED -> "unsupported"
            else -> "unknown"
        })
        val kg = ctx.getSystemService(Context.KEYGUARD_SERVICE) as KeyguardManager
        o.put("screen_lock_set", kg.isDeviceSecure)

        // Serial number: corporate device owner only, and only when Android allows it.
        if (mode == "device_owner") {
            try { @Suppress("MissingPermission") Build.getSerial().takeIf { it != Build.UNKNOWN }?.let { o.put("serial_number", it) } }
            catch (e: SecurityException) { /* not accessible: do not report */ }
        }
        return o
    }
}

package com.vayora.mdm.agent.core

import android.app.admin.DevicePolicyManager
import android.content.ComponentName
import android.content.Context
import android.os.Build
import android.os.UserManager
import com.vayora.mdm.agent.admin.VayoraDeviceAdminReceiver
import com.vayora.mdm.agent.data.Store
import org.json.JSONArray
import org.json.JSONObject

/**
 * Applies the policy the server sent through DevicePolicyManager. Every control reports back whether it
 * was really applied (APIs throw SecurityException when the Agent lacks the required ownership).
 */
object PolicyEnforcer {
    fun apply(ctx: Context, enforce: JSONObject, extraBlocked: Set<String>): JSONObject {
        val dpm = ctx.getSystemService(Context.DEVICE_POLICY_SERVICE) as DevicePolicyManager
        val admin = ComponentName(ctx, VayoraDeviceAdminReceiver::class.java)
        val result = JSONObject()
        val isOwner = dpm.isDeviceOwnerApp(ctx.packageName) || dpm.isProfileOwnerApp(ctx.packageName)

        fun run(key: String, block: () -> String?) {
            if (!enforce.has(key)) return
            val r = JSONObject()
            try {
                if (!isOwner) throw SecurityException("Agent is not device owner or profile owner")
                r.put("applied", true); r.put("detail", block() ?: "applied")
            } catch (e: Exception) {
                r.put("applied", false); r.put("detail", e.message ?: e.javaClass.simpleName)
            }
            result.put(key, r)
        }
        fun restriction(key: String, name: String) = run(key) {
            if (enforce.getBoolean(key)) dpm.addUserRestriction(admin, name) else dpm.clearUserRestriction(admin, name)
            null
        }

        run("password_quality") {
            val q = when (enforce.getString("password_quality")) {
                "numeric" -> DevicePolicyManager.PASSWORD_QUALITY_NUMERIC
                "alphabetic" -> DevicePolicyManager.PASSWORD_QUALITY_ALPHABETIC
                "alphanumeric" -> DevicePolicyManager.PASSWORD_QUALITY_ALPHANUMERIC
                "complex" -> DevicePolicyManager.PASSWORD_QUALITY_COMPLEX
                else -> DevicePolicyManager.PASSWORD_QUALITY_UNSPECIFIED
            }
            @Suppress("DEPRECATION") dpm.setPasswordQuality(admin, q)
            if (!dpm.isActivePasswordSufficient) "set; user must update the screen lock" else null
        }
        run("password_min_length") { @Suppress("DEPRECATION") dpm.setPasswordMinimumLength(admin, enforce.getInt("password_min_length")); null }
        run("max_failed_attempts") { dpm.setMaximumFailedPasswordsForWipe(admin, enforce.getInt("max_failed_attempts")); null }
        run("max_time_to_lock_sec") { dpm.setMaximumTimeToLock(admin, enforce.getInt("max_time_to_lock_sec") * 1000L); null }
        run("disable_camera") { dpm.setCameraDisabled(admin, enforce.getBoolean("disable_camera")); null }
        run("disable_screen_capture") { dpm.setScreenCaptureDisabled(admin, enforce.getBoolean("disable_screen_capture")); null }
        restriction("disable_usb_file_transfer", UserManager.DISALLOW_USB_FILE_TRANSFER)
        restriction("block_unknown_sources", UserManager.DISALLOW_INSTALL_UNKNOWN_SOURCES)
        restriction("block_cross_profile_copy_paste", UserManager.DISALLOW_CROSS_PROFILE_COPY_PASTE)
        run("disable_usb_data_signaling") {
            if (Build.VERSION.SDK_INT < 31) throw UnsupportedOperationException("requires Android 12+")
            dpm.setUsbDataSignalingEnabled(!enforce.getBoolean("disable_usb_data_signaling")); null
        }

        run("always_on_vpn_package") {
            val pkg = enforce.getString("always_on_vpn_package").ifEmpty { null }
            dpm.setAlwaysOnVpnPackage(admin, pkg, pkg != null && enforce.optBoolean("vpn_lockdown", false))
            if (pkg == null) "cleared" else null
        }
        run("wifi_profiles") {
            val arr = enforce.getJSONArray("wifi_profiles")
            if (arr.length() == 0) return@run "none configured"
            val wm = ctx.applicationContext.getSystemService(Context.WIFI_SERVICE) as android.net.wifi.WifiManager
            if (Build.VERSION.SDK_INT >= 29) {
                val list = (0 until arr.length()).map {
                    val n = arr.getJSONObject(it)
                    android.net.wifi.WifiNetworkSuggestion.Builder().setSsid(n.getString("ssid")).apply {
                        if (n.getString("security") == "wpa2") setWpa2Passphrase(n.getString("password"))
                    }.build()
                }
                val st = wm.addNetworkSuggestions(list)
                if (st != android.net.wifi.WifiManager.STATUS_NETWORK_SUGGESTIONS_SUCCESS &&
                    st != android.net.wifi.WifiManager.STATUS_NETWORK_SUGGESTIONS_ERROR_ADD_DUPLICATE)
                    throw IllegalStateException("Wi-Fi suggestion status $st")
                "${list.size} network(s) provisioned"
            } else {
                @Suppress("DEPRECATION")
                for (i in 0 until arr.length()) {
                    val n = arr.getJSONObject(i)
                    val c = android.net.wifi.WifiConfiguration().apply {
                        SSID = "\"" + n.getString("ssid") + "\""
                        if (n.getString("security") == "wpa2") preSharedKey = "\"" + n.getString("password") + "\""
                        else allowedKeyManagement.set(android.net.wifi.WifiConfiguration.KeyMgmt.NONE)
                    }
                    val id = wm.addNetwork(c)
                    if (id >= 0) wm.enableNetwork(id, false)
                }
                "${arr.length()} network(s) provisioned"
            }
        }
        run("kiosk_packages") {
            val arr = enforce.getJSONArray("kiosk_packages")
            val pkgs = Array(arr.length()) { arr.getString(it) }
            dpm.setLockTaskPackages(admin, if (pkgs.isEmpty()) emptyArray<String>() else pkgs + ctx.packageName)
            if (Build.VERSION.SDK_INT >= 28) dpm.setLockTaskFeatures(admin, DevicePolicyManager.LOCK_TASK_FEATURE_NONE)
            Store(ctx).kioskPackage = pkgs.firstOrNull()
            if (pkgs.isEmpty()) "cleared" else "kiosk allowed; start it from the Agent screen"
        }

        // Blocked apps: policy list plus apps assigned with intent "blocked".
        val blocked = HashSet<String>(extraBlocked)
        enforce.optJSONArray("blocked_packages")?.let { a: JSONArray -> for (i in 0 until a.length()) blocked.add(a.getString(i)) }
        if (enforce.has("blocked_packages") || blocked.isNotEmpty()) {
            val store = Store(ctx)
            val r = JSONObject()
            try {
                if (!isOwner) throw SecurityException("Agent is not device owner or profile owner")
                val nowHidden = HashSet<String>()
                for (pkg in blocked) {
                    if (pkg == ctx.packageName) continue
                    try { if (dpm.setApplicationHidden(admin, pkg, true) || dpm.isApplicationHidden(admin, pkg)) nowHidden.add(pkg) }
                    catch (e: Exception) { /* package not present in this scope */ }
                }
                for (pkg in store.hiddenByUs - blocked) try { dpm.setApplicationHidden(admin, pkg, false) } catch (e: Exception) {}
                store.hiddenByUs = nowHidden
                r.put("applied", true); r.put("detail", "${nowHidden.size} app(s) hidden")
            } catch (e: Exception) { r.put("applied", false); r.put("detail", e.message) }
            if (enforce.has("blocked_packages")) result.put("blocked_packages", r)
        }
        return result
    }
}

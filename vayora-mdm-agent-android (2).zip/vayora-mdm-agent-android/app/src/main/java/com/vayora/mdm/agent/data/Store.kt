package com.vayora.mdm.agent.data

import android.content.Context
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import java.security.KeyStore
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec

/** Local state. Tokens are encrypted with a non-exportable Android Keystore key (AES-GCM). */
class Store(ctx: Context) {
    private val sp = ctx.applicationContext.getSharedPreferences("vayora_store", Context.MODE_PRIVATE)

    var serverUrl: String?
        get() = sp.getString("server", null)
        set(v) = sp.edit().putString("server", v).apply()

    var deviceId: Long
        get() = sp.getLong("device_id", 0)
        set(v) = sp.edit().putLong("device_id", v).apply()

    var deviceToken: String?
        get() = sp.getString("token", null)?.let { decrypt(it) }
        set(v) = sp.edit().apply { if (v == null) remove("token") else putString("token", encrypt(v)) }.apply()

    /** One-time enrollment token waiting to be exchanged for a device token. */
    var pendingToken: String?
        get() = sp.getString("pending_token", null)?.let { decrypt(it) }
        set(v) = sp.edit().apply { if (v == null) remove("pending_token") else putString("pending_token", encrypt(v)) }.apply()

    /** Firebase options (JSON) received from the server at enrollment; null when push is not configured. */
    var pushConfig: String?
        get() = sp.getString("push_config", null)
        set(v) = sp.edit().putString("push_config", v).apply()

    var pushRegistered: Boolean
        get() = sp.getBoolean("push_registered", false)
        set(v) = sp.edit().putBoolean("push_registered", v).apply()

    var kioskPackage: String?
        get() = sp.getString("kiosk_pkg", null)
        set(v) = sp.edit().apply { if (v == null) remove("kiosk_pkg") else putString("kiosk_pkg", v) }.apply()

    var lastError: String?
        get() = sp.getString("last_error", null)
        set(v) = sp.edit().putString("last_error", v).apply()

    var lastSync: Long
        get() = sp.getLong("last_sync", 0)
        set(v) = sp.edit().putLong("last_sync", v).apply()

    var policyName: String?
        get() = sp.getString("policy_name", null)
        set(v) = sp.edit().putString("policy_name", v).apply()

    var policyVersion: Int
        get() = sp.getInt("policy_version", 0)
        set(v) = sp.edit().putInt("policy_version", v).apply()

    var compliance: String?
        get() = sp.getString("compliance", null)
        set(v) = sp.edit().putString("compliance", v).apply()

    /** JSON of enforcement results (key -> {applied, detail}) sent with the next check-in. */
    var lastApplied: String
        get() = sp.getString("applied", "{}") ?: "{}"
        set(v) = sp.edit().putString("applied", v).apply()

    /** Packages this Agent hid because of policy (so they can be un-hidden if the policy changes). */
    var hiddenByUs: Set<String>
        get() = sp.getStringSet("hidden", emptySet()) ?: emptySet()
        set(v) = sp.edit().putStringSet("hidden", v).apply()

    fun appStatus(pkg: String): String? = sp.getString("app_$pkg", null)
    fun setAppStatus(pkg: String, status: String?) =
        sp.edit().apply { if (status == null) remove("app_$pkg") else putString("app_$pkg", status) }.apply()

    fun clearEnrollment() = sp.edit().clear().apply()
    val enrolled: Boolean get() = deviceToken != null

    // ---- Keystore AES-GCM
    private fun key(): SecretKey {
        val ks = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
        (ks.getKey(ALIAS, null) as? SecretKey)?.let { return it }
        val gen = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore")
        gen.init(
            KeyGenParameterSpec.Builder(ALIAS, KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT)
                .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                .setKeySize(256).build()
        )
        return gen.generateKey()
    }

    private fun encrypt(plain: String): String {
        val c = Cipher.getInstance("AES/GCM/NoPadding").apply { init(Cipher.ENCRYPT_MODE, key()) }
        val out = c.iv + c.doFinal(plain.toByteArray())
        return Base64.encodeToString(out, Base64.NO_WRAP)
    }

    private fun decrypt(enc: String): String? = try {
        val raw = Base64.decode(enc, Base64.NO_WRAP)
        val c = Cipher.getInstance("AES/GCM/NoPadding")
            .apply { init(Cipher.DECRYPT_MODE, key(), GCMParameterSpec(128, raw, 0, 12)) }
        String(c.doFinal(raw, 12, raw.size - 12))
    } catch (e: Exception) { null }

    companion object { private const val ALIAS = "vayora_token_key" }
}

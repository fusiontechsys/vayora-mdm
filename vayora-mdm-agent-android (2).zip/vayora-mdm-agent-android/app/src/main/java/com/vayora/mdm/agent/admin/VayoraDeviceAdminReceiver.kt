package com.vayora.mdm.agent.admin

import android.app.admin.DeviceAdminReceiver
import android.app.admin.DevicePolicyManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.os.PersistableBundle
import com.vayora.mdm.agent.data.Store
import com.vayora.mdm.agent.work.Scheduler

/**
 * Entry point for Android Enterprise provisioning. Android calls [onProfileProvisioningComplete] after
 * either device-owner provisioning (QR code on a factory-reset device) or work-profile creation (BYOD).
 * The enrollment token and server URL arrive in the provisioning "admin extras" bundle.
 */
class VayoraDeviceAdminReceiver : DeviceAdminReceiver() {

    @Suppress("DEPRECATION")
    override fun onProfileProvisioningComplete(context: Context, intent: Intent) {
        val extras = intent.getParcelableExtra<PersistableBundle>(DevicePolicyManager.EXTRA_PROVISIONING_ADMIN_EXTRAS_BUNDLE)
        val server = extras?.getString("server_url")
        val token = extras?.getString("enrollment_token")
        val store = Store(context)
        val dpm = context.getSystemService(Context.DEVICE_POLICY_SERVICE) as DevicePolicyManager
        val admin = ComponentName(context, VayoraDeviceAdminReceiver::class.java)

        // Work profile: it must be enabled before apps inside it can run.
        if (dpm.isProfileOwnerApp(context.packageName) && !dpm.isDeviceOwnerApp(context.packageName)) {
            dpm.setProfileName(admin, "Vayora Work")
            dpm.setProfileEnabled(admin)
        }
        if (server != null && token != null) {
            store.serverUrl = server
            store.pendingToken = token
            Scheduler.enqueueEnroll(context)
        } else {
            store.lastError = "Provisioning finished without enrollment data. Re-create the enrollment in the console."
        }
    }

    override fun onDisabled(context: Context, intent: Intent) {
        Scheduler.cancelAll(context)
    }
}

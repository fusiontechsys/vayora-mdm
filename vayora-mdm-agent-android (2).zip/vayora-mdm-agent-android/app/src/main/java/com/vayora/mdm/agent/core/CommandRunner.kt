package com.vayora.mdm.agent.core

import android.app.admin.DevicePolicyManager
import android.content.ComponentName
import android.content.Context
import com.vayora.mdm.agent.admin.VayoraDeviceAdminReceiver
import com.vayora.mdm.agent.data.Store
import com.vayora.mdm.agent.net.ApiClient
import org.json.JSONObject

/** Executes remote commands from the console. Only commands the platform really supports are accepted. */
object CommandRunner {
    fun run(ctx: Context, store: Store, cmd: JSONObject, assigned: org.json.JSONArray) {
        val id = cmd.getLong("id")
        val type = cmd.getString("type")
        val dpm = ctx.getSystemService(Context.DEVICE_POLICY_SERVICE) as DevicePolicyManager
        val admin = ComponentName(ctx, VayoraDeviceAdminReceiver::class.java)
        val mode = DeviceInfo.managementMode(ctx)
        fun report(ok: Boolean, msg: String) = try {
            ApiClient.post(store.serverUrl!!, "/api/v1/device/commands/$id/result", store.deviceToken,
                JSONObject().put("success", ok).put("message", msg))
        } catch (e: Exception) { null }

        try {
            when (type) {
                "LOCK" -> { requireOwner(mode); dpm.lockNow(); report(true, "locked") }
                "REBOOT" -> {
                    require(mode == "device_owner") { "Restart needs device-owner mode" }
                    report(true, "restarting"); dpm.reboot(admin)
                }
                "SYNC" -> report(true, "synced")
                "LOST_MODE" -> {
                    requireOwner(mode)
                    val p = cmd.getJSONObject("payload")
                    val info = listOf(p.optString("message"), p.optString("phone").takeIf { it.isNotEmpty() }?.let { "Call: $it" })
                        .filterNotNull().filter { it.isNotEmpty() }.joinToString("\n")
                    if (mode == "device_owner") dpm.setDeviceOwnerLockScreenInfo(admin, info)
                    dpm.lockNow()
                    report(true, if (mode == "device_owner") "lost mode on" else "locked (lock-screen message is only available on corporate devices)")
                }
                "END_LOST_MODE" -> {
                    if (mode == "device_owner") dpm.setDeviceOwnerLockScreenInfo(admin, null)
                    report(true, "lost mode ended")
                }
                "INSTALL_APP" -> {
                    val pkg = cmd.getJSONObject("payload").getString("package_name")
                    var found = false
                    for (i in 0 until assigned.length()) {
                        val a = assigned.getJSONObject(i)
                        if (a.getString("package_name") == pkg) { found = true; AppManager.ensureInstalled(ctx, a, store) }
                    }
                    if (found) report(true, "install started") else report(false, "app is not assigned to this device")
                }
                "REMOVE_APP" -> {
                    requireOwner(mode)
                    AppManager.uninstall(ctx, cmd.getJSONObject("payload").getString("package_name")); report(true, "uninstall requested")
                }
                "WIPE" -> {
                    require(mode == "device_owner") { "Factory reset needs device-owner mode" }
                    report(true, "factory reset initiated")        // report first: the token dies with the wipe
                    dpm.wipeData(0)
                }
                "REMOVE_WORK_PROFILE" -> {
                    require(mode == "profile_owner") { "Not a work-profile device" }
                    report(true, "work profile removal initiated")
                    dpm.wipeData(0)                                // on a profile owner this removes only the work profile
                }
                else -> report(false, "unsupported command")
            }
        } catch (e: Exception) { report(false, e.message ?: e.javaClass.simpleName) }
    }

    private fun requireOwner(mode: String) = require(mode != "none") { "Agent is not device owner or profile owner" }
}

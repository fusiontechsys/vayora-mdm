package com.vayora.mdm.agent.net

import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.security.MessageDigest

class ApiException(val code: Int, message: String) : Exception(message) {
    /** 4xx responses are permanent (do not retry); network errors and 5xx are transient. */
    val permanent get() = code in 400..499 && code != 408 && code != 429
}

object ApiClient {
    fun requireHttps(url: String): String {
        val u = url.trim().trimEnd('/')
        require(u.startsWith("https://")) { "Server URL must use https://" }
        return u
    }

    fun post(server: String, path: String, token: String?, body: JSONObject): JSONObject {
        val conn = URL(requireHttps(server) + path).openConnection() as HttpURLConnection
        try {
            conn.requestMethod = "POST"
            conn.connectTimeout = 20_000
            conn.readTimeout = 30_000
            conn.doOutput = true
            conn.setRequestProperty("Content-Type", "application/json")
            if (token != null) conn.setRequestProperty("Authorization", "Bearer $token")
            conn.outputStream.use { it.write(body.toString().toByteArray()) }
            val code = conn.responseCode
            val text = (if (code in 200..299) conn.inputStream else conn.errorStream)
                ?.bufferedReader()?.use { it.readText() } ?: ""
            val json = try { JSONObject(text) } catch (e: Exception) { JSONObject() }
            if (code !in 200..299) throw ApiException(code, json.optString("error", "HTTP $code"))
            return json
        } finally { conn.disconnect() }
    }

    /** Downloads over HTTPS and verifies the SHA-256 before returning the file. */
    fun download(url: String, dest: File, expectedSha256: String) {
        require(url.startsWith("https://")) { "APK URL must use https://" }
        val conn = URL(url).openConnection() as HttpURLConnection
        val md = MessageDigest.getInstance("SHA-256")
        try {
            conn.connectTimeout = 20_000; conn.readTimeout = 60_000
            if (conn.responseCode != 200) throw ApiException(conn.responseCode, "download failed")
            dest.parentFile?.mkdirs()
            conn.inputStream.use { input -> dest.outputStream().use { out ->
                val buf = ByteArray(16 * 1024)
                while (true) { val n = input.read(buf); if (n < 0) break; md.update(buf, 0, n); out.write(buf, 0, n) }
            } }
        } finally { conn.disconnect() }
        val actual = md.digest().joinToString("") { "%02x".format(it) }
        if (!actual.equals(expectedSha256, ignoreCase = true)) { dest.delete(); throw SecurityException("APK checksum mismatch") }
    }
}

package com.vayora.mdm.agent.core

import android.content.Context
import com.vayora.mdm.agent.data.Store
import com.vayora.mdm.agent.net.ApiClient
import com.vayora.mdm.agent.net.ApiException
import org.json.JSONArray
import org.json.JSONObject

object SyncEngine {
    sealed class Outcome {
        object Ok : Outcome()
        object NotEnrolled : Outcome()
        data class Retry(val reason: String) : Outcome()
        data class Fatal(val reason: String) : Outcome()
    }

    @Synchronized
    fun sync(ctx: Context): Outcome {
        val store = Store(ctx)
        val server = store.serverUrl
        val token = store.deviceToken
        if (server == null || token == null) return Outcome.NotEnrolled
        return try {
            val mode = DeviceInfo.managementMode(ctx)
            val body = JSONObject()
                .put("device", DeviceInfo.collect(ctx))
                .put("apps", withInstallStatus(ctx, store))
                .put("apps_complete", true)
                .put("applied", JSONObject(store.lastApplied))
                .put("policy_version", store.policyVersion)
            val resp = ApiClient.post(server, "/api/v1/device/checkin", token, body)

            val policy = resp.getJSONObject("policy")
            val assigned = resp.optJSONArray("apps") ?: JSONArray()
            val canManage = mode != "none"
            val blockedByApp = AppManager.reconcile(ctx, assigned, canManage)
            val applied = PolicyEnforcer.apply(ctx, policy.getJSONObject("enforce"), blockedByApp)
            val changed = applied.toString() != store.lastApplied || policy.getInt("version") != store.policyVersion
            store.lastApplied = applied.toString()
            store.policyVersion = policy.getInt("version")
            store.policyName = policy.optString("policy_name")
            store.compliance = resp.optString("compliance")

            val cmds = resp.optJSONArray("commands") ?: JSONArray()
            for (i in 0 until cmds.length()) CommandRunner.run(ctx, store, cmds.getJSONObject(i), assigned)

            if (changed) {   // second check-in so compliance reflects what was just enforced
                val r2 = ApiClient.post(server, "/api/v1/device/checkin", token, JSONObject()
                    .put("device", DeviceInfo.collect(ctx)).put("applied", applied).put("policy_version", store.policyVersion))
                store.compliance = r2.optString("compliance")
            }
            store.lastSync = System.currentTimeMillis()
            store.lastError = null
            if (store.pushConfig != null && !store.pushRegistered) com.vayora.mdm.agent.work.Scheduler.enqueuePushRegister(ctx)
            Outcome.Ok
        } catch (e: ApiException) {
            if (e.code == 401) { store.lastError = "This device was removed from management."; store.clearEnrollment(); Outcome.Fatal("revoked") }
            else { store.lastError = e.message; if (e.permanent) Outcome.Fatal(e.message ?: "") else Outcome.Retry(e.message ?: "") }
        } catch (e: Exception) {
            store.lastError = e.message
            Outcome.Retry(e.message ?: "network error")
        }
    }

    private fun withInstallStatus(ctx: Context, store: Store): JSONArray {
        val apps = AppManager.listManaged(ctx)
        val installed = HashSet<String>().also { s -> for (i in 0 until apps.length()) s.add(apps.getJSONObject(i).getString("package_name")) }
        // Surface attempted-but-not-installed apps (failed / installing) so the console shows installation status.
        val prefs = ctx.getSharedPreferences("vayora_store", Context.MODE_PRIVATE)
        for ((k, v) in prefs.all) {
            if (!k.startsWith("app_") || v !is String) continue
            val pkg = k.removePrefix("app_")
            if (pkg in installed) continue
            apps.put(JSONObject().put("scope", "managed").put("package_name", pkg)
                .put("install_status", if (v.startsWith("installing")) "installing" else "failed"))
        }
        return apps
    }

    fun enroll(ctx: Context): Outcome {
        val store = Store(ctx)
        val server = store.serverUrl
        val pending = store.pendingToken
        if (server == null || pending == null) return Outcome.NotEnrolled
        return try {
            val info = DeviceInfo.collect(ctx)
            info.put("name", "${info.optString("manufacturer")} ${info.optString("model")}".trim())
            val resp = ApiClient.post(server, "/api/v1/device/enroll", null,
                JSONObject().put("enrollment_token", pending).put("device", info))
            store.deviceToken = resp.getString("device_token")
            store.deviceId = resp.getLong("device_id")
            store.pendingToken = null
            store.lastError = null
            resp.optJSONObject("push")?.let { store.pushConfig = it.toString(); store.pushRegistered = false }
            com.vayora.mdm.agent.work.Scheduler.enqueuePushRegister(ctx)
            Outcome.Ok
        } catch (e: ApiException) {
            store.lastError = e.message
            if (e.permanent) { store.pendingToken = null; Outcome.Fatal(e.message ?: "") } else Outcome.Retry(e.message ?: "")
        } catch (e: Exception) { store.lastError = e.message; Outcome.Retry(e.message ?: "network error") }
    }
}

package com.vayora.mdm.agent.push

import com.google.firebase.messaging.FirebaseMessagingService
import com.google.firebase.messaging.RemoteMessage
import com.vayora.mdm.agent.data.Store
import com.vayora.mdm.agent.work.Scheduler

/** The push carries no data except "sync now"; everything else is fetched over the authenticated API. */
class VayoraMessagingService : FirebaseMessagingService() {
    override fun onMessageReceived(message: RemoteMessage) {
        if (Store(this).enrolled) Scheduler.syncNow(this)
    }

    override fun onNewToken(token: String) {
        val store = Store(this)
        store.pushRegistered = false
        if (store.enrolled) Scheduler.enqueuePushRegister(this)
    }
}

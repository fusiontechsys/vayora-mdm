package com.vayora.mdm.agent.admin

import android.app.Activity
import android.app.admin.DevicePolicyManager
import android.content.Intent
import android.os.Build
import android.os.Bundle

/** Android 12+: tells the setup wizard which management mode this DPC wants for the provisioning flow. */
class GetProvisioningModeActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (Build.VERSION.SDK_INT >= 31) {
            @Suppress("DEPRECATION")
            val allowed = intent.getIntegerArrayListExtra(DevicePolicyManager.EXTRA_PROVISIONING_ALLOWED_PROVISIONING_MODES)
                ?: arrayListOf()
            val mode = when {
                allowed.contains(DevicePolicyManager.PROVISIONING_MODE_FULLY_MANAGED_DEVICE) ->
                    DevicePolicyManager.PROVISIONING_MODE_FULLY_MANAGED_DEVICE
                allowed.contains(DevicePolicyManager.PROVISIONING_MODE_MANAGED_PROFILE) ->
                    DevicePolicyManager.PROVISIONING_MODE_MANAGED_PROFILE
                else -> null
            }
            if (mode != null) {
                setResult(RESULT_OK, Intent().putExtra(DevicePolicyManager.EXTRA_PROVISIONING_MODE, mode))
            } else setResult(RESULT_CANCELED)
        } else setResult(RESULT_CANCELED)
        finish()
    }
}

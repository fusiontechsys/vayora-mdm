package com.vayora.mdm.agent.core

import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageInstaller
import android.content.pm.PackageManager
import android.os.Build
import com.vayora.mdm.agent.data.Store
import com.vayora.mdm.agent.net.ApiClient
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

/** Reports apps inside the managed scope and installs / removes assigned apps. */
object AppManager {
    /** Lists installed apps visible to the Agent. In a work profile Android only exposes work-profile apps. */
    fun listManaged(ctx: Context): JSONArray {
        val pm = ctx.packageManager
        val arr = JSONArray()
        val store = Store(ctx)
        for (p in pm.getInstalledPackages(0)) {
            val ai = p.applicationInfo ?: continue
            val system = ai.flags and android.content.pm.ApplicationInfo.FLAG_SYSTEM != 0
            if (system && pm.getLaunchIntentForPackage(p.packageName) == null) continue
            arr.put(JSONObject().apply {
                put("scope", "managed")
                put("package_name", p.packageName)
                put("app_name", pm.getApplicationLabel(ai).toString())
                put("version_name", p.versionName ?: "")
                @Suppress("DEPRECATION") put("version_code", if (Build.VERSION.SDK_INT >= 28) p.longVersionCode.coerceAtMost(Int.MAX_VALUE.toLong()).toInt() else p.versionCode)
                put("install_status", "installed")
            })
        }

        return arr
    }

    fun installedVersion(ctx: Context, pkg: String): Long? = try {
        val p = ctx.packageManager.getPackageInfo(pkg, 0)
        if (Build.VERSION.SDK_INT >= 28) p.longVersionCode else @Suppress("DEPRECATION") p.versionCode.toLong()
    } catch (e: PackageManager.NameNotFoundException) { null }

    /** Brings the device in line with required / uninstall assignments. Returns blocked package names. */
    fun reconcile(ctx: Context, assigned: JSONArray, canManage: Boolean): Set<String> {
        val store = Store(ctx)
        val blocked = HashSet<String>()
        for (i in 0 until assigned.length()) {
            val a = assigned.getJSONObject(i)
            val pkg = a.getString("package_name")
            when (a.getString("intent")) {
                "blocked" -> blocked.add(pkg)
                "uninstall" -> if (canManage && installedVersion(ctx, pkg) != null) uninstall(ctx, pkg)
                "required" -> if (canManage) ensureInstalled(ctx, a, store)
            }
        }
        return blocked
    }

    fun ensureInstalled(ctx: Context, a: JSONObject, store: Store) {
        val pkg = a.getString("package_name")
        val want = a.optLong("version_code", 0)
        val have = installedVersion(ctx, pkg)
        if (have != null && have >= want) { store.setAppStatus(pkg, null); return }
        if (a.optString("source") != "private_apk" || a.isNull("apk_url")) {
            // Managed Google Play deployment needs an Android Enterprise binding with Google; this Agent
            // does not pretend to install Play apps on its own.
            store.setAppStatus(pkg, "failed: requires Managed Google Play")
            return
        }
        try {
            store.setAppStatus(pkg, "installing")
            val f = File(ctx.cacheDir, "apks/$pkg.apk")
            ApiClient.download(a.getString("apk_url"), f, a.getString("apk_sha256"))
            install(ctx, pkg, f)
        } catch (e: Exception) { store.setAppStatus(pkg, "failed: ${e.message}") }
    }

    private fun install(ctx: Context, pkg: String, apk: File) {
        val installer = ctx.packageManager.packageInstaller
        val params = PackageInstaller.SessionParams(PackageInstaller.SessionParams.MODE_FULL_INSTALL)
        params.setAppPackageName(pkg)
        if (Build.VERSION.SDK_INT >= 31) params.setRequireUserAction(PackageInstaller.SessionParams.USER_ACTION_NOT_REQUIRED)
        val id = installer.createSession(params)
        installer.openSession(id).use { s ->
            apk.inputStream().use { input -> s.openWrite("pkg", 0, apk.length()).use { out -> input.copyTo(out); s.fsync(out) } }
            val pi = PendingIntent.getBroadcast(ctx, id, Intent(ctx, InstallResultReceiver::class.java).putExtra("pkg", pkg),
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_MUTABLE)
            s.commit(pi.intentSender)
        }
        apk.delete()
    }

    fun uninstall(ctx: Context, pkg: String) {
        val pi = PendingIntent.getBroadcast(ctx, pkg.hashCode(), Intent(ctx, InstallResultReceiver::class.java).putExtra("pkg", pkg).putExtra("uninstall", true),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_MUTABLE)
        ctx.packageManager.packageInstaller.uninstall(pkg, pi.intentSender)
    }
}

class InstallResultReceiver : android.content.BroadcastReceiver() {
    override fun onReceive(ctx: Context, intent: Intent) {
        val pkg = intent.getStringExtra("pkg") ?: return
        val status = intent.getIntExtra(PackageInstaller.EXTRA_STATUS, PackageInstaller.STATUS_FAILURE)
        val store = Store(ctx)
        when (status) {
            PackageInstaller.STATUS_SUCCESS -> store.setAppStatus(pkg, null)
            PackageInstaller.STATUS_PENDING_USER_ACTION -> store.setAppStatus(pkg, "failed: needs user confirmation (Agent is not device/profile owner)")
            else -> store.setAppStatus(pkg, "failed: ${intent.getStringExtra(PackageInstaller.EXTRA_STATUS_MESSAGE) ?: status}")
        }
    }
}

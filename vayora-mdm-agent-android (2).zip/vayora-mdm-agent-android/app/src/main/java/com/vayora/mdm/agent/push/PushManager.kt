package com.vayora.mdm.agent.push

import android.content.Context
import com.google.firebase.FirebaseApp
import com.google.firebase.FirebaseOptions
import com.vayora.mdm.agent.data.Store
import org.json.JSONObject

object PushManager {
    /** Initialises Firebase from the options the server sent at enrollment. Returns false if push is not configured. */
    @Synchronized
    fun init(ctx: Context): Boolean {
        val cfg = Store(ctx).pushConfig ?: return false
        return try {
            if (FirebaseApp.getApps(ctx).isEmpty()) {
                val j = JSONObject(cfg)
                val b = FirebaseOptions.Builder()
                    .setApplicationId(j.getString("app_id"))
                    .setApiKey(j.getString("api_key"))
                    .setProjectId(j.getString("project_id"))
                j.optString("sender_id").takeIf { it.isNotEmpty() }?.let { b.setGcmSenderId(it) }
                FirebaseApp.initializeApp(ctx.applicationContext, b.build())
            }
            true
        } catch (e: Exception) { false }
    }
}

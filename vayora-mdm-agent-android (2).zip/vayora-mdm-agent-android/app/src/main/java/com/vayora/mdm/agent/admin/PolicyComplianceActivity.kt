package com.vayora.mdm.agent.admin

import android.app.Activity
import android.os.Bundle

/** Final provisioning step: the Agent has nothing extra to ask the user, so it accepts immediately. */
class PolicyComplianceActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setResult(RESULT_OK)
        finish()
    }
}

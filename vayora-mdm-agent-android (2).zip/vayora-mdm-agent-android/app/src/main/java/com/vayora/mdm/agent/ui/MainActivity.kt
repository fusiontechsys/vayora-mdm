package com.vayora.mdm.agent.ui

import android.app.Activity
import android.app.admin.DevicePolicyManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.os.PersistableBundle
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.widget.*
import com.vayora.mdm.agent.BuildConfig
import com.vayora.mdm.agent.admin.VayoraDeviceAdminReceiver
import com.vayora.mdm.agent.core.DeviceInfo
import com.vayora.mdm.agent.data.Store
import com.vayora.mdm.agent.net.ApiClient
import com.vayora.mdm.agent.work.Scheduler
import java.text.DateFormat
import java.util.Date

/**
 * Status screen, plus the BYOD entry point. Corporate devices are never enrolled from here: device-owner
 * provisioning can only happen from the setup wizard (QR code on a new / factory-reset device).
 */
class MainActivity : Activity() {
    private lateinit var root: LinearLayout
    private val blue = Color.parseColor("#1558D6")

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val sv = ScrollView(this)
        root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(40, 60, 40, 40) }
        sv.addView(root); setContentView(sv)
        handleLink(intent)
    }

    override fun onNewIntent(intent: Intent) { super.onNewIntent(intent); setIntent(intent); handleLink(intent) }
    override fun onResume() { super.onResume(); draw() }

    private var linkServer: String? = null
    private var linkToken: String? = null

    private fun handleLink(i: Intent?) {
        val d = i?.data ?: return
        if (d.scheme == "vayora" && d.host == "enroll") { linkServer = d.getQueryParameter("server"); linkToken = d.getQueryParameter("token") }
    }

    private fun text(s: String, size: Float = 15f, bold: Boolean = false, color: Int = Color.parseColor("#1B2433")) =
        TextView(this).apply { text = s; textSize = size; setTextColor(color); if (bold) setTypeface(typeface, android.graphics.Typeface.BOLD); setPadding(0, 10, 0, 10) }

    private fun button(label: String, onClick: () -> Unit) = Button(this).apply {
        text = label; isAllCaps = false; setTextColor(Color.WHITE); setBackgroundColor(blue); setOnClickListener { onClick() }
    }

    private fun draw() {
        root.removeAllViews()
        val store = Store(this)
        val mode = DeviceInfo.managementMode(this)
        root.addView(text("Vayora MDM Agent", 24f, true, blue))
        root.addView(text("Version ${BuildConfig.VERSION_NAME}", 12f, color = Color.GRAY))

        if (store.enrolled) {
            root.addView(text("Managed device", 18f, true))
            root.addView(text("Mode: " + when (mode) { "device_owner" -> "Corporate (fully managed)"; "profile_owner" -> "Work profile (BYOD)"; else -> "Unknown" }))
            root.addView(text("Server: ${store.serverUrl}"))
            root.addView(text("Policy: ${store.policyName ?: "—"}"))
            root.addView(text("Compliance: ${store.compliance ?: "—"}"))
            root.addView(text("Last sync: " + if (store.lastSync > 0) DateFormat.getDateTimeInstance().format(Date(store.lastSync)) else "never"))
            store.lastError?.let { root.addView(text("Last error: $it", 13f, color = Color.parseColor("#C62828"))) }
            root.addView(button("Sync now") { Scheduler.syncNow(this); Toast.makeText(this, "Sync started", Toast.LENGTH_SHORT).show() })
            val dpm = getSystemService(Context.DEVICE_POLICY_SERVICE) as DevicePolicyManager
            store.kioskPackage?.let { pkg ->
                if (mode == "device_owner" && dpm.isLockTaskPermitted(pkg)) root.addView(button("Start kiosk app") {
                    val li = packageManager.getLaunchIntentForPackage(pkg)
                    if (li == null) toast("Kiosk app is not installed yet") else {
                        val o = android.app.ActivityOptions.makeBasic().apply { setLockTaskEnabled(true) }
                        startActivity(li, o.toBundle())
                    }
                })
            }
            if (mode != "none" && !dpm.isActivePasswordSufficient) {
                root.addView(text("Your screen lock does not meet your organisation's requirements.", 14f, color = Color.parseColor("#A15C00")))
                root.addView(button("Update screen lock") { startActivity(Intent(DevicePolicyManager.ACTION_SET_NEW_PASSWORD)) })
            }
            root.addView(text("What your organisation can see: device model, Android version, battery, storage, encryption and " +
                "screen-lock status" + (if (mode == "profile_owner") ", and apps inside the work profile only. Your personal apps, files, messages and location are not visible." else ", and managed apps."), 12f, color = Color.GRAY))
            return
        }

        if (mode == "device_owner" || store.pendingToken != null) {
            root.addView(text("Enrolling…", 18f, true))
            root.addView(text(store.lastError ?: "Contacting the Vayora MDM server."))
            root.addView(button("Retry") { Scheduler.enqueueEnroll(this); draw() })
            return
        }

        root.addView(text("Enrol this personal device", 18f, true))
        root.addView(text("This creates a separate work profile. Your organisation manages only the work profile; your personal apps and data stay private.", 14f))
        val server = EditText(this).apply { hint = "Server URL (https://…)"; inputType = InputType.TYPE_TEXT_VARIATION_URI; setText(linkServer ?: "") }
        val token = EditText(this).apply { hint = "Enrollment token"; setText(linkToken ?: "") }
        root.addView(server); root.addView(token)
        root.addView(button("Create work profile") { startByod(server.text.toString(), token.text.toString().trim()) })
        root.addView(text("Corporate-owned devices cannot be enrolled from this screen. Factory-reset the device and scan the enrollment QR code on the welcome screen (tap it six times).", 12f, color = Color.GRAY).apply { gravity = Gravity.START })
    }

    private fun startByod(serverIn: String, token: String) {
        val server = try { ApiClient.requireHttps(serverIn) } catch (e: Exception) { toast(e.message ?: "Invalid server URL"); return }
        if (token.length < 8) { toast("Enter the enrollment token"); return }
        val dpm = getSystemService(Context.DEVICE_POLICY_SERVICE) as DevicePolicyManager
        if (!dpm.isProvisioningAllowed(DevicePolicyManager.ACTION_PROVISION_MANAGED_PROFILE)) {
            toast("This device cannot create a work profile (already has one, or is not supported)."); return
        }
        val i = Intent(DevicePolicyManager.ACTION_PROVISION_MANAGED_PROFILE)
            .putExtra(DevicePolicyManager.EXTRA_PROVISIONING_DEVICE_ADMIN_COMPONENT_NAME, ComponentName(this, VayoraDeviceAdminReceiver::class.java))
            .putExtra(DevicePolicyManager.EXTRA_PROVISIONING_ADMIN_EXTRAS_BUNDLE,
                PersistableBundle().apply { putString("server_url", server); putString("enrollment_token", token) })
        if (i.resolveActivity(packageManager) == null) { toast("Work profiles are not supported on this device."); return }
        @Suppress("DEPRECATION") startActivityForResult(i, 1)
    }

    private fun toast(m: String) = Toast.makeText(this, m, Toast.LENGTH_LONG).show()
}

# Vayora MDM Agent (Android)
Kotlin Android Enterprise agent (device owner + work profile). Package `com.vayora.mdm.agent`, minSdk 26.
Phone-only build: push this folder to a GitHub repo, run **Actions > Generate release keystore** once, add the 4 secrets
it lists, then **Actions > Build Vayora MDM Agent APK** and download the `vayora-mdm-agent` artifact.
Upload that APK to the server at `backend/instance/agent/vayora-mdm-agent.apk`.
Not yet compiled or run on a device: expect to fix small compile errors on the first build.

package com.vayora.mdm.agent.work

import android.content.Context
import androidx.work.*
import com.vayora.mdm.agent.core.SyncEngine
import java.util.concurrent.TimeUnit

class EnrollWorker(ctx: Context, p: WorkerParameters) : Worker(ctx, p) {
    override fun doWork(): Result = when (SyncEngine.enroll(applicationContext)) {
        is SyncEngine.Outcome.Ok -> { Scheduler.schedulePeriodic(applicationContext); Scheduler.syncNow(applicationContext); Result.success() }
        is SyncEngine.Outcome.Retry -> Result.retry()
        else -> Result.failure()
    }
}

class SyncWorker(ctx: Context, p: WorkerParameters) : Worker(ctx, p) {
    override fun doWork(): Result = when (SyncEngine.sync(applicationContext)) {
        is SyncEngine.Outcome.Retry -> Result.retry()
        else -> Result.success()
    }
}

object Scheduler {
    private val net = Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build()

    fun enqueueEnroll(ctx: Context) {
        WorkManager.getInstance(ctx).enqueueUniqueWork("enroll", ExistingWorkPolicy.REPLACE,
            OneTimeWorkRequestBuilder<EnrollWorker>().setConstraints(net)
                .setBackoffCriteria(BackoffPolicy.EXPONENTIAL, 30, TimeUnit.SECONDS).build())
    }

    /** Android's minimum periodic interval is 15 minutes; commands are delivered at the next check-in. */
    fun schedulePeriodic(ctx: Context) {
        WorkManager.getInstance(ctx).enqueueUniquePeriodicWork("sync", ExistingPeriodicWorkPolicy.UPDATE,
            PeriodicWorkRequestBuilder<SyncWorker>(15, TimeUnit.MINUTES).setConstraints(net).build())
    }

    fun syncNow(ctx: Context) {
        WorkManager.getInstance(ctx).enqueueUniqueWork("sync-now", ExistingWorkPolicy.REPLACE,
            OneTimeWorkRequestBuilder<SyncWorker>().setConstraints(net).build())
    }

    fun cancelAll(ctx: Context) = WorkManager.getInstance(ctx).cancelAllWork()
}
